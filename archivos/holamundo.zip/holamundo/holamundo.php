<?php
	echo "Hola, son las ".date("H:i:s");
?>